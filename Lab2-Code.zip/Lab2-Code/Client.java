import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try {
            // Assuming the RMI registry is located on localhost, port 1099
            Registry registry = LocateRegistry.getRegistry("localhost", 1099);
            // Lookup the remote object that implements IActivity
            IActivity activity = (IActivity) registry.lookup("ActivityService");

            try (Scanner scanner = new Scanner(System.in)) {
                while (true) {
                    System.out.println("Enter command ('exit' to quit):");
                    String command = scanner.nextLine();
                    if ("exit".equalsIgnoreCase(command)) {
                        break;
                    }

                    System.out.println("Enter parameters (comma separated, 'none' for no parameters):");
                    String parametersLine = scanner.nextLine();
                    String[] parameters = parametersLine.equals("none") ? new String[0] : parametersLine.split(",");

                    try {
                        String result = activity.execute(command, parameters);
                        System.out.println("Result: " + result);
                    } catch (Exception e) {
                        System.err.println("Error executing command: " + e.getMessage());
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Client exception: " + e);
            e.printStackTrace();
        }
    }
}
