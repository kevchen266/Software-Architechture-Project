import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface IActivity extends Remote {
    /**
     * Executes a specified command or action remotely.
     * This method is designed to be flexible, allowing various types of operations
     * to be performed based on the input parameters.
     *
     * @param action Specifies the action to be performed, e.g., "listAllStudents".
     * @param parameters Additional parameters required for executing the action.
     * @return Returns a result of the execution, which could be information about students, courses, etc.
     * @throws RemoteException If there is an error during remote method invocation.
     */
    String execute(String action, String... parameters) throws RemoteException;
}
