Implicit-Invocation System

Author: Kaichun Chen

1.Compile all the files: 
In your CMD (command prompt) or shell, execute ---> javac *.java

2.Exucute Main function
In your CMD (command prompt) or shell, execute-->java SystemMain Students.txt Courses.txt

3,Make sure to input courseID and section in uppercase.

